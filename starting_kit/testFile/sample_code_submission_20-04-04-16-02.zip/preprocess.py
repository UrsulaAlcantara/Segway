import warnings

with warnings.catch_warnings():
    warnings.filterwarnings("ignore", category=DeprecationWarning)
    import numpy as np
    import pandas as pd
    from sklearn.neighbors import LocalOutlierFactor


class Preprocessor():
    def __init__(self):
        self.transformer = LocalOutlierFactor(n_neighbors= 200)

    def fit_predict(self, data):
        shuffle = data.copy()
        shuffle = shuffle.reindex(np.random.permutation(shuffle.index))
        outliers = shuffle.copy()
        outliers['outliers'] = pd.Series(self.transformer.fit_predict(outliers),
                                         index=outliers.index)
        outliers = outliers[outliers['outliers'] == 1]
        outliers = outliers.drop('outliers', 1)
        Y = outliers.iloc[:, -1]
        X = outliers.iloc[:, 0:-1]
        return X, Y